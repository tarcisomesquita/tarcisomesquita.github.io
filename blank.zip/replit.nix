{ pkgs }: {
  deps = [ ];
}
