#define UART0 ((volatile unsigned int*)0x101f1000)
#define UARTFR 0x06        // offset (in words) from the "UART0" base address of the flags for the serial port
#define UARTFR_TXFF 0x20   // mask that gets the bit representing if the transmit buffer is full.

void bwputs(char *s) {
   while(*s) {
      while(*(UART0 + UARTFR) & UARTFR_TXFF);
      *UART0 = *s;
      s++;
   }
}

int main(void) {
   bwputs("Hello, World! 1_1\n");
   while(1); // We can't exit, there's nowhere to go
   return 0;
}

