rm build/disk.raw.lock
bochs -f bochsrc-linux.bxrc -q
