qemu-system-x86_64 -hda build/disk.raw -m 16 -smp 2 -rtc base=localtime
