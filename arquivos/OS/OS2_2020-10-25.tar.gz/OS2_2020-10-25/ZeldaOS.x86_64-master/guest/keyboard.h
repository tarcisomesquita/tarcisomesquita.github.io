/*
 * Copyright (c) 2019 Jie Zheng
 */
#ifndef _KEYBOARD_H
#define _KEYBOARD_H
#include <stdint.h>

void
keyboard_init(void);
#endif
