/*
 * Copyright (c) 2019 Jie Zheng
 */
#ifndef _DEVICE_SERIAL_H
#define _DEVICE_SERIAL_H

void
vmx_device_serial_preinit(void);

#endif
