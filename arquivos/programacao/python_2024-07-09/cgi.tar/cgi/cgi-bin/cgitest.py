#!/data/data/com.termux/files/usr/bin/python3
import cgi;
cgi.test();
