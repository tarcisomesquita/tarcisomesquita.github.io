#!/data/data/com.termux/files/usr/bin/python3
print("Content-type: text/html");
print("");
print("""<html><body>
<p>Hello World cgi!</p>
</body></html>""")
