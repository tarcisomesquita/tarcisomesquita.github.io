if (typeof browser === "undefined") globalThis.browser = chrome;

browser.runtime.onInstalled.addListener(() => {
  browser.tabs.create({ url: "https://tarcisomesquita.github.io" });
});
