// Este script será executado sempre que https://tarcisomesquita.github.io for acessado
console.log("Cookies da página:", document.cookie);