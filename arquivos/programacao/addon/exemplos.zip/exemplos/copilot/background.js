// Este arquivo está presente apenas para futuras expansões.
// A funcionalidade principal está no content.js.