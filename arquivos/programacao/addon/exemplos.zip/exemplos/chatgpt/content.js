// Este script roda toda vez que a página for carregada
console.log("Cookies da página:", document.cookie);
