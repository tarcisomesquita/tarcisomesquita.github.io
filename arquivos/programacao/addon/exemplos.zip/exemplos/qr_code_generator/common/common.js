/**
 * Just load/does common stuff.
 *
 * @module common
 * @requires modules/Localizer
 */
"use strict";

// by default translate whole site
import "/common/modules/Localizer/Localizer.js";
