import * as MobileOptions from "/common/modules/AutomaticSettings/MobileOptions.js";

// hide not mobile compatible settings
MobileOptions.init();
