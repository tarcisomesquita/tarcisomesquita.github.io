<a target="_blank" href="https://chrome.google.com/webstore/detail/ahlcocbkjpjkobcdpjcobmibmpbeecpg">![Try it now in CWS](https://raw.github.com/GoogleChrome/chrome-extensions-samples/main/_archive/apps/tryitnowbutton.png "Click here to install this sample from the Chrome Web Store")</a>


# Chrome Commando TCP server

This is a sample that shows how you can run a network TCP server in a packaged app. This sample allows you to start a server in an arbitrary address and port. Telnet to the listening port and you will be able to remotely control your browser by sending some commands such as `open` and `echo`.

## APIs

* [Sockets](https://developer.chrome.com/apps/sockets_tcp)
* [Runtime](https://developer.chrome.com/apps/app_runtime)
* [Window](https://developer.chrome.com/apps/app_window)

## Screenshot
![screenshot](/_archive/apps/samples/tcpserver/assets/screenshot_1280_800.png)

