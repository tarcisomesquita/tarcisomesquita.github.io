
// The simplest kernel module.
// apt-get install build-essential kernel-package
// make
// insmod /home/ubuntu/Desktop/hello-1/hello-1.ko 
// rmmod hello-1

#include <linux/module.h> // Needed by all modules
#include <linux/kernel.h> // Needed for KERN_INFO

// init_module() is called when the module is insmoded into the kernel
int init_module(void) {
   printk(KERN_INFO "Hello world 1.\n"); // printk append message to /var/log/messages
   return 0; // A non 0 return means init_module failed; module can't be loaded.
}

// cleanup_module() is called just before it is rmmoded
void cleanup_module(void) {
   printk(KERN_INFO "Goodbye world 1.\n"); // printk append message to /var/log/messages
}

